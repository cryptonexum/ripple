const path = require('path');

module.exports = {
  mode: 'production',
  entry: './backend.js', // Entry point of your server-side code
  output: {
    filename: 'bundle.js', // Output filename
    path: path.resolve(__dirname, 'dist') // Output directory
  },
  resolve: {
    fallback: {
        path: require.resolve('path-browserify')
    }
},
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env']
          }
        }
      }
    ]
  }
};
